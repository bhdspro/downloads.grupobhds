// detect.js
// Este script procura silenciosamente pela página de tutorial do Grupo BHDS.
// Se achar, ele avisa a página que a instalação foi concluída.

const detectorDiv = document.getElementById('bhds-install-detector');

if (detectorDiv) {
    detectorDiv.value = "installed";
}