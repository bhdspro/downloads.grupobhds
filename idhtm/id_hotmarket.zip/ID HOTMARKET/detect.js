// detect.js
// Dispara um evento customizado direto para a página (Resposta mais rápida)
document.dispatchEvent(new CustomEvent('bhds-extension-installed'));

// Fallback: altera o valor do input escondido na página de tutorial do Grupo BHDS
const detectorDiv = document.getElementById('bhds-install-detector');
if (detectorDiv) {
    detectorDiv.value = "installed";
}