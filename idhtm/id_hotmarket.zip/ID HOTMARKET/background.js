// background.js
// Este arquivo aguarda o usuário clicar no ícone da extensão na barra do navegador.
// Quando clicado, ele não abre janela. Ele manda um sinal invisível para copiar o ID.

chrome.action.onClicked.addListener((tab) => {
    // Envia um sinal para o content.js da aba atual copiar o ID
    chrome.tabs.sendMessage(tab.id, { action: "copy_id" }).catch(() => {
        // Ignora erros caso o usuário clique na extensão em um site que não seja da Hotmart
    });
});