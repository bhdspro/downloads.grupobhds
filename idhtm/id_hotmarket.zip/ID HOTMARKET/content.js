// content.js

// Função para copiar texto para a área de transferência
function copiarParaClipboard(texto) {
  const tempElement = document.createElement('textarea');
  tempElement.value = texto;
  document.body.appendChild(tempElement);
  tempElement.select();
  document.execCommand('copy');
  document.body.removeChild(tempElement);
}

// Variável para armazenar o ID do produto
let currentProductId = null;

// 1. Busca o ID do produto no código do site (Independente do visual da página)
function extrairProductId() {
  const scriptTags = document.querySelectorAll('script');
  scriptTags.forEach(tag => {
    const match = tag.innerHTML.match(/"productId":(\d+)/);
    if (match) {
      currentProductId = match[1];
    }
  });
}

// 2. OPÇÃO 1: Tenta adicionar o emoticon 🆔 visualmente ao lado do título
function adicionarEmoticon() {
  if (!currentProductId) return; // Se não achou o ID no site, não faz nada

  // Tenta achar o título principal da página
  const h1 = document.querySelector('h1'); 
  
  if (h1) {
    const spanEmoticon = document.createElement('span');
    spanEmoticon.innerHTML = '🆔';
    spanEmoticon.style.cursor = 'pointer';
    spanEmoticon.style.marginRight = '8px'; // Dá um espacinho entre o emoticon e o texto
    spanEmoticon.title = `ID do Produto: ${currentProductId}`;

    // Adiciona o evento de clique no emoticon
    spanEmoticon.addEventListener('click', function() {
      copiarParaClipboard(currentProductId);
    });

    h1.prepend(spanEmoticon);
  }
}

// Executa a extração do ID silenciosamente
extrairProductId();

// Tenta colocar o emoticon na tela para o usuário (Opção 1)
adicionarEmoticon();

// 3. OPÇÃO 2: Escuta o clique no ícone da extensão lá na barra do navegador (Cópia silenciosa)
// Se o emoticon falhar em aparecer por mudanças no site, esta opção continuará funcionando!
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "copy_id" && currentProductId) {
    copiarParaClipboard(currentProductId);
  }
});